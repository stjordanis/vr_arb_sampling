# Python Preprocessor for LIBSVM dataset
from scipy.sparse import lil_matrix
import numpy as np

name = "cpusmall_scaled"
lines = list(open(name, 'r'))
num_features = 22  # corresponds to number of features, check the dataset
A = lil_matrix((num_features, len(lines)))
counter = 0
y = np.zeros(len(lines))
# check y, sometimes preprocessing step needs to be changed, dummy is responsible for y creation , check file first
for i in range(len(lines)):
    if np.mod(i, 2000) == 0:
        print("Processing line: ", i)
    dummy = [w.replace('\n', '') for w in lines[i].split(" ")]
    # if dummy[0] == "1":
    #     y[i] = 1
    y[i] = int(dummy[0])
    for j in range(1, len(dummy)):
        cc = dummy[j].split(":")
        A[int(cc[0])-1, i] = float(cc[1])

print(A.shape)
print('y_sum... ', np.sum(y))
A = lil_matrix.tocsc(A)
np.save('row_'+name+'.npy', A.indices+1)
np.save('ind_'+name+'.npy', A.indptr+1)
np.save('dat_'+name+'.npy', A.data)
np.save('y_'+name+'.npy', y)
print(A.nonzero)
